#!/bin/bash
cd /sources
tar vxf xterm-325.tgz
cd xterm-325
sed -i '/v0/{n;s/new:/new:kb=^?:/}' termcap
printf '\tkbs=\\177,\n' >> terminfo
TERMINFO=/usr/share/terminfo PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --with-app-defaults=/etc/X11/app-defaults
make
make install
make install-ti
ldconfig
cat >> /etc/X11/app-defaults/XTerm << "EOF"
*VT100*locale: true
*VT100*faceName: Monospace
*VT100*faceSize: 10
*backarrowKeyIsErase: true
*ptyInitialErase: true
EOF
cd ..
rm -vfr xterm-325

