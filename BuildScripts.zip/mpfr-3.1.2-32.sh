#!/tools/bin/bash
tar vxf mpfr-3.1.2.tar.xz
cd mpfr-3.1.2
patch -Np1 -i ../mpfr-3.1.2-fixes-4.patch
cp -v /usr/share/automake-1.14/missing .
cp -v /usr/share/automake-1.14/test-driver .
CC="gcc -isystem /usr/include ${BUILD32}" LDFLAGS="-Wl,-rpath-link,/usr/lib:/lib ${BUILD32}" ./configure --prefix=/usr --host=${__A_TARGET32} --docdir=/usr/share/doc/mpfr-3.1.2
make
make install
cd ..
rm -vfr mpfr-3.1.2

