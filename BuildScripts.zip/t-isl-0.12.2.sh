#!/bin/bash
tar vxf isl-0.12.2.tar.lzma
cd isl-0.12.2
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/tools/lib64
make
make install
cd ..
rm -vfr isl-0.12.2

