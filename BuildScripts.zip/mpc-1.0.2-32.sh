#!/tools/bin/bash
tar vxf mpc-1.0.2.tar.gz
cd mpc-1.0.2
CC="gcc -isystem /usr/include ${BUILD32}" LDFLAGS="-Wl,-rpath-link,/usr/lib:/lib ${BUILD32}" ./configure --prefix=/usr --host=${__A_TARGET32}
make
make install
cd ..
rm -vfr mpc-1.0.2

