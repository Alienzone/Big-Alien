#!/tools/bin/bash
tar vxf util-linux-2.24.2.tar.xz
cd util-linux-2.24.2
sed -i -e 's@etc/adjtime@var/lib/hwclock/adjtime@g' $(grep -rl '/etc/adjtime' .)
mkdir -pv /var/lib/hwclock
CC="gcc ${BUILD64}" ./configure --libdir=/lib64 --enable-write --docdir=/usr/share/doc/util-linux-2.24.2
make
make install
mv -v /usr/bin/logger /bin
cd ..
rm -vfr util-linux-2.24.2

