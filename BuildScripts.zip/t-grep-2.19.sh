#!/bin/bash
tar vxf grep-2.19.tar.xz
cd grep-2.19
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --without-included-regex
make
make install
cd ..
rm -vfr grep-2.19

