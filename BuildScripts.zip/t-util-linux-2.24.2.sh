#!/bin/bash
tar vxf util-linux-2.24.2.tar.xz
cd util-linux-2.24.2
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/usr/lib64 --disable-makeinstall-chown --disable-makeinstall-setuid
make
make install
cd ..
rm -vfr util-linux-2.24.2

