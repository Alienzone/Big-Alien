#!/bin/bash
tar vxf xkeyboard-config-2.18.tar.bz2
cd xkeyboard-config-2.18
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc --with-xkb-rules-symlink=xorg
make
make install
ldconfig
mv -v /usr/share/pkgconfig/* /usr/lib64/pkgconfig/
cd ..
rm -vfr xkeyboard-config-2.18

