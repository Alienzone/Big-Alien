#!/tools/bin/bash
tar vxf mpfr-3.1.2.tar.xz
cd mpfr-3.1.2
patch -Np1 -i ../mpfr-3.1.2-fixes-4.patch
cp -v /usr/share/automake-1.14/missing .
cp -v /usr/share/automake-1.14/test-driver .
CC="gcc -isystem /usr/include ${BUILD64}" LDFLAGS="-Wl,-rpath-link,/usr/lib64:/lib64 ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --docdir=/usr/share/doc/mpfr-3.1.2
make
make install
cd ..
rm -vfr mpfr-3.1.2

