#!/bin/bash
tar vxf util-macros-1.19.0.tar.bz2
cd util-macros-1.19.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
mv -v /usr/share/pkgconfig/xorg-macros.pc /usr/lib/pkgconfig/xorg-macros.pc
ldconfig
cd ..
rm -vfr util-macros-1.19.0

