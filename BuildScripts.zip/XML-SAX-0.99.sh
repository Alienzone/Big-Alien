#!/bin/bash
tar vxf XML-SAX-0.99.tar.gz
cd XML-SAX-0.99
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-SAX-0.99

