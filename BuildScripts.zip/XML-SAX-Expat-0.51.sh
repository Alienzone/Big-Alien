#!/bin/bash
tar vxf XML-SAX-Expat-0.51.tar.gz
cd XML-SAX-Expat-0.51
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-SAX-Expat-0.51

