#!/bin/bash
tar vxf gzip-1.6.tar.xz
cd gzip-1.6
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr gzip-1.6

