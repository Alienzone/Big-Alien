#!/bin/bash
tar vxf nettle-3.2.tar.gz
cd nettle-3.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
chmod   -v   755 /usr/lib64/lib{hogweed,nettle}.so
ldconfig
cd ..
rm -vfr nettle-3.2

