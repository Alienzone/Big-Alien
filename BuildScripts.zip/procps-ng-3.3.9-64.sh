#!/tools/bin/bash
tar vxf procps-ng-3.3.9.tar.xz
cd procps-ng-3.3.9
CC="gcc ${BUILD64}" ./configure --prefix=/usr --exec-prefix= --libdir=/usr/lib64 --docdir=/usr/share/doc/procps-ng-3.3.9 --disable-kill
make
make install
mv -v /usr/bin/pidof /bin
mv -v /usr/lib64/libprocps.so.* /lib64
ln -sfv ../../lib64/$(readlink /usr/lib64/libprocps.so) /usr/lib64/libprocps.so
cd ..
rm -vfr procps-ng-3.3.9

