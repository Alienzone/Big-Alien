#!/bin/bash
cd /sources
tar vxf printproto-1.0.5.tar.bz2
cd printproto-1.0.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr printproto-1.0.5

