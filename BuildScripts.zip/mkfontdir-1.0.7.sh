#!/bin/bash
cd /sources
tar vxf mkfontdir-1.0.7.tar.bz2
cd mkfontdir-1.0.7
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr mkfontdir-1.0.7

