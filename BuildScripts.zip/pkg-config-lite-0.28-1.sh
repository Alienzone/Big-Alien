#!/tools/bin/bash
tar vxf pkg-config-lite-0.28-1.tar.gz
cd pkg-config-lite-0.28-1
CC="gcc ${BUILD64}" ./configure --prefix=/usr --docdir=/usr/share/doc/pkg-config-0.28-1 --with-pc-path=/usr/share/pkgconfig
make
make install
cat >> /root/.bashrc << EOF
export PKG_CONFIG_PATH32="/usr/lib/pkgconfig"
export PKG_CONFIG_PATH64="/usr/lib64/pkgconfig"
EOF
cd ..
rm -vfr pkg-config-lite-0.28-1

