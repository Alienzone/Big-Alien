#!/bin/bash
tar vxf patch-2.7.1.tar.xz
cd patch-2.7.1
CC="gcc ${BUILD64}" ./configure --prefix=/usr
make
make install
cd ..
rm -vfr patch-2.7.1

