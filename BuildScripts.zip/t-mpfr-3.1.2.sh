#!/bin/bash
tar vxf mpfr-3.1.2.tar.xz
cd mpfr-3.1.2
patch -Np1 -i ../mpfr-3.1.2-fixes-4.patch
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/tools/lib64
make
make install
cd ..
rm -vfr mpfr-3.1.2

