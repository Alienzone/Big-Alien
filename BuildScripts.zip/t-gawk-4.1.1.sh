#!/bin/bash
tar vxf gawk-4.1.1.tar.xz
cd gawk-4.1.1
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr gawk-4.1.1

