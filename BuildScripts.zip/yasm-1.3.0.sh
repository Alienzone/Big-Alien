#!/bin/bash
cd /sources
tar vxf yasm-1.3.0.tar
cd yasm-1.3.0
sed -i 's#) ytasm.*#)#' Makefile.in
USE_ARCH=32 CC="gcc -fPIC ${BUILD32}" ./configure --prefix=/usr --libdir=/usr/lib
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr yasm-1.3.0
tar vxf yasm-1.3.0.tar
cd yasm-1.3.0
sed -i 's#) ytasm.*#)#' Makefile.in
USE_ARCH=64 CC="gcc -fPIC ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr yasm-1.3.0

