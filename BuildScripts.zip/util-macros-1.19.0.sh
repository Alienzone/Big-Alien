#!/bin/bash
cd /sources
tar vxf util-macros-1.19.0.tar.bz2
cd util-macros-1.19.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
sleep 3
make install
sleep 3
mv -v /usr/share/pkgconfig/xorg-macros.pc /usr/lib64/pkgconfig/xorg-macros.pc
ldconfig
cd ..
rm -vfr util-macros-1.19.0

