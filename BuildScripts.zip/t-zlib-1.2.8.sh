#!/bin/bash
tar vxf zlib-1.2.8.tar.xz
cd zlib-1.2.8
./configure --prefix=/tools --libdir=/tools/lib64
make
make install
cd ..
rm -vfr zlib-1.2.8

