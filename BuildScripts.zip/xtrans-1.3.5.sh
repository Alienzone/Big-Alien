#!/bin/bash
cd /sources
tar vxf xtrans-1.3.5.tar.bz2
cd xtrans-1.3.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
sleep 3
make install
ldconfig
mv -v /usr/share/pkgconfig/xtrans.pc /usr/lib64/pkgconfig/xtrans.pc
cd ..
rm -vfr xtrans-1.3.5

