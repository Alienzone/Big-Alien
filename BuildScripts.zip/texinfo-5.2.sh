#!/bin/bash
tar vxf texinfo-5.2.tar.xz
cd texinfo-5.2
CC="gcc ${BUILD64}" ./configure --prefix=/usr
make
make install
cd ..
rm -vfr texinfo-5.2

