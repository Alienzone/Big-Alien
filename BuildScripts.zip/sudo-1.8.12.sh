#!/bin/bash
tar vxf sudo-1.8.12.tar.gz
cd sudo-1.8.12
CC="gcc ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --with-secure-path --with-all-insults --with-env-editor --docdir=/usr/share/doc/sudo-1.8.12 --with-passprompt="[sudo] password for %p"
make
make install
cat > /etc/sudoers << "EOF"
# User alias specification
User_Alias  ADMIN = __a

# Allow people in group ADMIN to run all commands without a password
ADMIN       ALL = NOPASSWD: ALL
EOF
cd ..
rm -vfr sudo-1.8.12

