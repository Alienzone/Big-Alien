#!/bin/bash
cd /sources
tar vxf Python-3.5.2.tar.xz
cd Python-3.5.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --enable-shared --with-system-expat --with-system-ffi --with-ensurepip=install --disable-ipv6 --with-universal-archs=all --enable-big-digits --with-address-sanitizer
make
make install
chmod -v 755 /usr/lib64/libpython3.5m.so
chmod -v 755 /usr/lib64/libpython3.so
ldconfig
cd ..
rm -vfr Python-3.5.2
#cat >> /etc/profile.d/99-Extras.sh << "EOF"
#export PYTHONPATH=/usr/lib/python3.5
#export PYTHONHOME=/usr/lib/python3.5
#EOF

