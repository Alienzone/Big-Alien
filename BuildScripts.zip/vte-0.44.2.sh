#!/bin/bash
cd /sources
tar vxf vte-0.44.2.tar.xz
cd vte-0.44.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-introspection=no --disable-gtk-doc-html --without-gnutls --enable-vala=no
make
make install
ldconfig
cd ..
rm -vfr vte-0.44.2

