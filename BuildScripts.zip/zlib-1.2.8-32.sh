#!/tools/bin/bash
tar vxf zlib-1.2.8.tar.xz
cd zlib-1.2.8
CC="gcc -isystem /usr/include ${BUILD32}" CXX="g++ -isystem /usr/include ${BUILD32}" LDFLAGS="-Wl,-rpath-link,/usr/lib:/lib ${BUILD32}" ./configure --prefix=/usr
make
make install
mv -v /usr/lib/libz.so.* /lib
ln -sfv ../../lib/$(readlink /usr/lib/libz.so) /usr/lib/libz.so
cd ..
rm -vfr zlib-1.2.8

