#!/bin/bash
cd /sources
tar vxf pygobject-2.28.6.tar.xz
cd pygobject-2.28.6
patch -Np1 -i ../pygobject-2.28.6-fixes-1.patch
sed -i "/seems to be moved/s/^/#/" ltmain.sh
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib --disable-introspection
make
make install
ldconfig
cd ..
rm -vfr pygobject-2.28.6

tar vxf pygobject-2.28.6.tar.xz
cd pygobject-2.28.6
patch -Np1 -i ../pygobject-2.28.6-fixes-1.patch
sed -i "/seems to be moved/s/^/#/" ltmain.sh
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --disable-introspection
make
make install
ldconfig
cd ..
rm -vfr pygobject-2.28.6

