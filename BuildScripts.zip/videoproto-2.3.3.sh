#!/bin/bash
cd /sources
tar vxf videoproto-2.3.3.tar.bz2
cd videoproto-2.3.3
CC="gcc ${BUILD64}" PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" ./configure --prefix=/usr
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr videoproto-2.3.3

