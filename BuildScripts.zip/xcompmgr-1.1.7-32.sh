#!/bin/bash
tar vxf xcompmgr-1.1.7.tar.bz2
cd xcompmgr-1.1.7
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xcompmgr-1.1.7

