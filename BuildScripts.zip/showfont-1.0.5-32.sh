#!/bin/bash
tar vxf showfont-1.0.5.tar.bz2
cd showfont-1.0.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr showfont-1.0.5

