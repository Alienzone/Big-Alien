#!/bin/bash
tar vxf openssl-1.0.1t.tar.gz
cd openssl-1.0.1t
setarch i386 ./Configure linux-generic32 ${BUILD32} --prefix=/usr --openssldir=/etc --libdir=/usr/lib shared zlib-dynamic 
make -j1 depend
make -j1
make -j1 install
cd ..
rm -vfr openssl-1.0.1t

