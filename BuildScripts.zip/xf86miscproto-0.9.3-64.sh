#!/bin/bash
tar vxf xf86miscproto-0.9.3.tar.bz2
cd xf86miscproto-0.9.3
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make install
ldconfig
cd ..
rm -vfr xf86miscproto-0.9.3

