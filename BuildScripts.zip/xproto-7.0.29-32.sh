#!/bin/bash
tar vxf xproto-7.0.29.tar.bz2
cd xproto-7.0.29
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
cd ..
rm -vfr xproto-7.0.29

