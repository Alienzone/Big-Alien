#!/bin/bash
tar vxf xf86dgaproto-2.1.tar.bz2
cd xf86dgaproto-2.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
cd ..
rm -vfr xf86dgaproto-2.1

