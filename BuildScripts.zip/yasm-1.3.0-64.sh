#!/bin/bash
tar vxf yasm-1.3.0.tar
cd yasm-1.3.0
sed -i 's#) ytasm.*#)#' Makefile.in
USE_ARCH=64 CC="gcc -fPIC ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64
make
make install
mv -v /usr/bin/yasm{,-64}
ln -svn /usr/bin/multiarch_wrapper /usr/bin/yasm
ldconfig
cd ..
rm -vfr yasm-1.3.0

