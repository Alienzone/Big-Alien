#!/bin/bash
tar vxf xkbcomp-1.3.1.tar.bz2
cd xkbcomp-1.3.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xkbcomp-1.3.1

