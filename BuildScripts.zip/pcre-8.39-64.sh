#!/bin/bash
cd /sources
tar vxf pcre-8.39.tar.bz2
cd pcre-8.39
CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --enable-pcre16 --enable-pcre32 --enable-utf --enable-unicode-properties --enable-pcretest-libreadline --enable-pcregrep-libz  --enable-pcregrep-libbz2 --enable-pcretest-libreadline
make
make install
mv -v /usr/bin/pcre-config{,-64}
ln -vs multiarch_wrapper /usr/bin/pcre-config
mv -v /usr/lib64/libpcre.so.* /lib64/
ln -svf ../../lib64/libpcre.so.1 /usr/lib64/libpcre.so
ldconfig
cd ..
rm -vfr pcre-8.39

