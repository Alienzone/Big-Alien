#!/bin/bash
tar vxf randrproto-1.5.0.tar.bz2
cd randrproto-1.5.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
cd ..
rm -vfr randrproto-1.5.0

