#!/tools/bin/bash
tar vxf sed-4.2.2.tar.bz2
cd sed-4.2.2
PKG_CONFIG_PATH=/tools/lib64 CC="gcc ${BUILD64}" ./configure --prefix=/usr --bindir=/bin --docdir=/usr/share/doc/sed-4.2.2
make
make install
cd ..
rm -vfr sed-4.2.2

