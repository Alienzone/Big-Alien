#!/bin/bash
tar vxf nettle-3.2.tar.gz
cd nettle-3.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
chmod   -v   755 /usr/lib/lib{hogweed,nettle}.so
ldconfig
cd ..
rm -vfr nettle-3.2

