#!/bin/bash
tar vxf findutils-4.4.2.tar.gz
cd findutils-4.4.2
echo "gl_cv_func_wcwidth_works=yes" > config.cache
echo "ac_cv_func_fnmatch_gnu=yes" >> config.cache
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --cache-file=config.cache
make
make install
cd ..
rm -vfr findutils-4.4.2

