#!/bin/bash
tar vxf tar-1.27.1.tar.xz
cd tar-1.27.1
patch -Np1 -i ../tar-1.27.1-manpage-1.patch
FORCE_UNSAFE_CONFIGURE=1 CC="gcc ${BUILD64}" ./configure --prefix=/usr --bindir=/bin --libexecdir=/usr/sbin
make
make install
perl tarman > /usr/share/man/man1/tar.1
make -C doc install-html docdir=/usr/share/doc/tar-1.27.1
cd ..
rm -vfr tar-1.27.1

