#!/bin/bash
cd /sources
tar vxf xinput-1.6.2.tar.bz2
cd xinput-1.6.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xinput-1.6.2

