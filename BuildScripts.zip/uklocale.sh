#!/bin/bash
cat >> /etc/profile << "EOF"

export LANG=en_GB.UTF-8

# End /etc/profile
EOF

