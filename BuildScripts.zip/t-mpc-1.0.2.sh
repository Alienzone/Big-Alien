#!/bin/bash
tar vxf mpc-1.0.2.tar.gz
cd mpc-1.0.2
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/tools/lib64
make
make install
cd ..
rm -vfr mpc-1.0.2

