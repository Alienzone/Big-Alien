#!/bin/bash
tar vxf cloog-0.18.2.tar.gz
cd cloog-0.18.2
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}  --libdir=/tools/lib64 --with-isl=system
cp -v Makefile{,.orig}
sed '/cmake/d' Makefile.orig > Makefile
make
make install
cd ..
rm -vfr cloog-0.18.2

