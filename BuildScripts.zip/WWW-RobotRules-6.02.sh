#!/bin/bash
cd /sources
tar vxf WWW-RobotRules-6.02.tar.gz
cd WWW-RobotRules-6.02
perl Makefile.PL
make
make install
cd ..
rm -vfr WWW-RobotRules-6.02

