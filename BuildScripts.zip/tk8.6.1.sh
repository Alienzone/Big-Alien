#!/tools/bin/bash
tar vxf tk8.6.1-src.tar.gz
cd tk8.6.1/unix
CC="gcc ${BUILD64}" ./configure --prefix=/tools --libdir=/tools/lib64 --enable-64bit
make
sed -e "s@^\(TK_SRC_DIR='\).*@\1/usr/include'@" -e "/TK_B/s@='\(-L\)\?.*unix@='\1/usr/lib@" -i tkConfig.sh
make install
make install-private-headers
ln -v -sf wish8.6 /tools/bin/wish
chmod -v 755 /tools/lib64/libtk8.6.so
cd ../..
rm -vfr tk8.6.1

