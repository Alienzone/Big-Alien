#!/bin/bash
tar vxf psmisc-22.21.tar.gz
cd psmisc-22.21
CC="gcc ${BUILD64}" ./configure --prefix=/usr
make
make install
cd ..
rm -vfr psmisc-22.21

