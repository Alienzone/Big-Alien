#!/tools/bin/bash
tar vxf ncurses-5.9.tar.gz
cd ncurses-5.9
patch -Np1 -i ../ncurses-5.9-branch_update-4.patch
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/lib64 --with-shared --without-debug --enable-widec --with-manpage-format=normal --enable-pc-files --with-default-terminfo-dir=/usr/share/terminfo
make
make install
mv -v /usr/bin/ncursesw5-config{,-64}
ln -svf multiarch_wrapper /usr/bin/ncursesw5-config
mv -v /lib64/lib{panelw,menuw,formw,ncursesw,ncurses++w}.a /usr/lib64
ln -svf ../../lib64/$(readlink /lib64/libncursesw.so) /usr/lib64/libncursesw.so
ln -svf ../../lib64/$(readlink /lib64/libmenuw.so) /usr/lib64/libmenuw.so
ln -svf ../../lib64/$(readlink /lib64/libpanelw.so) /usr/lib64/libpanelw.so
ln -svf ../../lib64/$(readlink /lib64/libformw.so) /usr/lib64/libformw.so
rm -v /lib64/lib{ncursesw,menuw,panelw,formw}.so
for lib in curses ncurses form panel menu ; do
        echo "INPUT(-l${lib}w)" > /usr/lib64/lib${lib}.so
        ln -sfv lib${lib}w.a /usr/lib64/lib${lib}.a
done
ln -sfv libcurses.so /usr/lib64/libcursesw.so
ln -sfv libncurses.so /usr/lib64/libcurses.so
ln -sfv libncursesw.a /usr/lib64/libcursesw.a
ln -sfv libncurses.a /usr/lib64/libcurses.a
ln -sfv libncurses++w.a /usr/lib64/libncurses++.a
ln -sfv ncursesw5-config-64 /usr/bin/ncurses5-config-64
ln -sfv ncursesw5-config /usr/bin/ncurses5-config
mv -v /usr/lib/pkgconfig/formw.pc /usr/lib64/pkgconfig
mv -v /usr/lib/pkgconfig/menuw.pc /usr/lib64/pkgconfig
mv -v /usr/lib/pkgconfig/ncurses++w.pc /usr/lib64/pkgconfig
mv -v /usr/lib/pkgconfig/ncursesw.pc /usr/lib64/pkgconfig
mv -v /usr/lib/pkgconfig/panelw.pc /usr/lib64/pkgconfig
mv -v /nct/formw.pc /usr/lib/pkgconfig
mv -v /nct/menuw.pc /usr/lib/pkgconfig
mv -v /nct/ncurses++w.pc /usr/lib/pkgconfig
mv -v /nct/ncursesw.pc /usr/lib/pkgconfig
mv -v /nct/panelw.pc /usr/lib/pkgconfig
rm -vfr /nct
cd ..
rm -vfr ncurses-5.9

