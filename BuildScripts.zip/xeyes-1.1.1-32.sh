#!/bin/bash
tar vxf xeyes-1.1.1.tar.bz2
cd xeyes-1.1.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xeyes-1.1.1

