#!/bin/bash
tar vxf tiff-4.0.6.tar.gz
cd tiff-4.0.6
sed -i "/seems to be moved/s/^/#/" config/ltmain.sh
CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" USE_ARCH=32 LDFLAGS="-L/usr/lib" ./configure --prefix=/usr --disable-static
make
make install
mv -v /usr/include/tiffconf{,-32}.h
ldconfig
cd ..
rm -vfr tiff-4.0.6

