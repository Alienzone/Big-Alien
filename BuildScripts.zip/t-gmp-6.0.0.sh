#!/bin/bash
tar vxf gmp-6.0.0a.tar.xz
cd gmp-6.0.0
CC_FOR_BUILD=gcc ./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/tools/lib64 --enable-cxx
make
make install
cd ..
rm -vfr gmp-6.0.0

