#!/tools/bin/bash
tar vxf perl-5.20.0.tar.bz2
cd perl-5.20.0
sed -i 's@/usr/include@/tools/include@g' ext/Errno/Errno_pm.PL
./configure.gnu --prefix=/tools  -Dcc="gcc ${BUILD32}"
make
make install
ln -sfv /tools/bin/perl /usr/bin
cd ..
rm -vfr perl-5.20.0

