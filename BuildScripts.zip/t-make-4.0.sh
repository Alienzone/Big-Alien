#!/bin/bash
tar vxf make-4.0.tar.bz2
cd make-4.0
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr make-4.0

