#!/bin/bash
cd /sources
tar vxf zip30.tar.gz 
cd zip30
make -f unix/Makefile generic_gcc
make prefix=/usr MANDIR=/usr/share/man/man1 -f unix/Makefile install
ldconfig
cd ..
rm -vfr zip30

