#!/bin/bash
tar vxf openssh-7.3p1.tar.gz
cd openssh-7.3p1
install -v -m700 -d /var/lib/sshd
chown   -v root:sys /var/lib/sshd
groupadd -g 50 sshd
useradd -c 'sshd PrivSep' -d /var/lib/sshd -g sshd -s /bin/false -u 50 sshd
CC="gcc ${BUILD64}" ./configure --prefix=/usr --libexecdir=/usr/sbin --sysconfdir=/etc/ssh --with-md5-passwords --with-privsep-path=/var/lib/sshd --with-superuser-path="/sbin:/bin:/usr/sbin:/usr/bin"
make
make install
install -v -m755 contrib/ssh-copy-id /usr/bin
install -v -m644 contrib/ssh-copy-id.1 /usr/share/man/man1
cd ..
rm -vfr openssh-7.3p1

