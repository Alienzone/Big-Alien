#!/bin/bash
tar vxf XML-Simple-2.22.tar.gz
cd XML-Simple-2.22
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-Simple-2.22

