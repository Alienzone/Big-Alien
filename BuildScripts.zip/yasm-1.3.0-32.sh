#!/bin/bash
tar vxf yasm-1.3.0.tar
cd yasm-1.3.0
sed -i 's#) ytasm.*#)#' Makefile.in
USE_ARCH=32 CC="gcc -fPIC ${BUILD32}" ./configure --prefix=/usr --libdir=/usr/lib
make
make install
mv -v /usr/bin/yasm{,-32}
ldconfig
cd ..
rm -vfr yasm-1.3.0

