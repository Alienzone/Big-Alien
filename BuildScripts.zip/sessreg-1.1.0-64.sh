#!/bin/bash
tar vxf sessreg-1.1.0.tar.bz2
cd sessreg-1.1.0
sed -e 's/\$(CPP) \$(DEFS)/$(CPP) -P $(DEFS)/' -i man/Makefile.in
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr sessreg-1.1.0

