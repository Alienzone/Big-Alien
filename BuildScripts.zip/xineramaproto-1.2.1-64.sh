#!/bin/bash
tar vxf xineramaproto-1.2.1.tar.bz2
cd xineramaproto-1.2.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make install
ldconfig
cd ..
rm -vfr xineramaproto-1.2.1

