#!/bin/bash
tar vxf xsetmode-1.0.0.tar.bz2
cd xsetmode-1.0.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xsetmode-1.0.0

