#!/tools/bin/bash
tar vxf readline-6.3.tar.gz
cd readline-6.3
patch -Np1 -i ../readline-6.3-branch_update-4.patch
CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/lib64 --docdir=/usr/share/doc/readline-6.3
make SHLIB_LIBS=-lncurses
make SHLIB_LIBS=-lncurses htmldir=/usr/share/doc/readline-6.3 install
mv -v /lib64/lib{readline,history}.a /usr/lib64
ln -svf ../../lib64/$(readlink /lib64/libreadline.so) /usr/lib64/libreadline.so
ln -svf ../../lib64/$(readlink /lib64/libhistory.so) /usr/lib64/libhistory.so
rm -v /lib64/lib{readline,history}.so
cd ..
rm -vfr readline-6.3

