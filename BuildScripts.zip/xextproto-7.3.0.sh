#!/bin/bash
cd /sources
tar vxf xextproto-7.3.0.tar.bz2
cd xextproto-7.3.0
CC="gcc ${BUILD64}" PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" ./configure --prefix=/usr
sleep 3
CC="gcc ${BUILD64}" make install
sleep 3
ldconfig
cd ..
rm -vfr xextproto-7.3.0

