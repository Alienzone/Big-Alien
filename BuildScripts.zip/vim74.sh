#!/bin/bash
tar vxf vim-7.4.tar.bz2
cd vim74
patch -Np1 -i ../vim-7.4-branch_update-7.patch
echo '#define SYS_VIMRC_FILE "/etc/vimrc"' >> src/feature.h
CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr
make
make install
ln -sv vim /usr/bin/vi
ln -sv ../vim/vim74/doc /usr/share/doc/vim-7.4
cat > /etc/vimrc << "EOF"
" Begin /etc/vimrc

set nocompatible
set backspace=2
set ruler
syntax on
if (&term == "iterm") || (&term == "putty")
  set background=dark
endif

" End /etc/vimrc
EOF
cd ..
rm -vfr vim74

