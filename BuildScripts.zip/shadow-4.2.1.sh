#!/tools/bin/bash
tar vxf shadow-4.2.1.tar.xz
cd shadow-4.2.1
sed -i src/Makefile.in -e 's/groups$(EXEEXT) //' -e 's/= nologin$(EXEEXT)/= /'
find man -name Makefile.in -exec sed -i -e 's/man1\/groups\.1 //' -e 's/man8\/nologin\.8 //' '{}' \;
CC="gcc ${BUILD64}" ./configure --sysconfdir=/etc
make
make install
sed -i /etc/login.defs -e 's@#\(ENCRYPT_METHOD \).*@\1SHA512@' -e 's@/var/spool/mail@/var/mail@'
mv -v /usr/bin/passwd /bin
pwconv
grpconv
cd ..
rm -vfr shadow-4.2.1

