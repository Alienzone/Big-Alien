#!/bin/bash
tar vxf mtdev-1.1.5.tar.bz2
cd mtdev-1.1.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr mtdev-1.1.5

