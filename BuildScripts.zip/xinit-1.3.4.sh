#!/bin/bash
cd /sources
tar vxf xinit-1.3.4.tar.bz2
cd xinit-1.3.4
sed -e '/$serverargs $vtarg/ s/serverargs/: #&/' -i startx.cpp
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --with-xinitdir=/etc/X11/app-defaults
make
make install
ldconfig
cd ..
rm -vfr xinit-1.3.4

