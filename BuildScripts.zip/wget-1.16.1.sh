#!/bin/bash
tar vxf wget-1.16.1.tar.xz
cd wget-1.16.1
CC="gcc ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --sysconfdir=/etc --with-ssl=openssl --disable-ipv6
make
make install
cd ..
rm -vfr wget-1.16.1

