#!/bin/bash
tar vxf openssl-1.0.1t.tar.gz
cd openssl-1.0.1t
patch -Np1 -i ../openssl-1.0.2-fix_parallel_build-1.patch
./Configure linux-x86_64 --prefix=/usr --openssldir=/etc shared zlib-dynamic
make depend
make
make install
ln -sv ../../etc/ssl /usr/share
cp -v -r certs /etc/ssl
cd ..
rm -vfr openssl-1.0.1t

