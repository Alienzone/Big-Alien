#!/bin/bash
tar vxf nss-3.26.tar.gz
cd nss-3.26
patch -Np1 -i ../nss-3.26-standalone-1.patch
cd nss
CC="gcc -m64" make -j1 BUILD_OPT=1 NSPR_INCLUDE_DIR=/usr/include/nspr USE_SYSTEM_ZLIB=1 ZLIB_LIBS=-lz USE_64=1 NSS_USE_SYSTEM_SQLITE=1
sleep 3
cd ../dist
install -v -m755 Linux*/lib64/*.so /usr/lib64
install -v -m644 Linux*/lib64/{*.chk,libcrmf.a} /usr/lib64
install -v -m755 -d /usr/include/nss
cp -v -RL {public,private}/nss/* /usr/include/nss
chmod -v 644 /usr/include/nss/*
install -v -m755 Linux*/bin/{certutil,nss-config,pk12util} /usr/bin
install -v -m644 Linux*/lib64/pkgconfig/nss.pc /usr/lib64/pkgconfig
sleep 3
cd ../..
rm -vfr nss-3.26

