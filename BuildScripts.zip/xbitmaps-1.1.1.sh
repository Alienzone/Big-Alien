#!/bin/bash
cd /sources
tar vxf xbitmaps-1.1.1.tar.bz2
cd xbitmaps-1.1.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
mv -v /usr/share/pkgconfig/xbitmaps.pc /usr/lib64/pkgconfig/xbitmaps.pc
cd ..
rm -vfr xbitmaps-1.1.1

