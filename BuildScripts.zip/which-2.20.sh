#!/bin/bash
tar vxf which-2.20.tar.gz
cd which-2.20
CC="gcc ${BUILD64}" ./configure --prefix=/usr
make
make install
cd ..
rm -vfr which-2.20

