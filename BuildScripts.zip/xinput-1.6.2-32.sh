#!/bin/bash
tar vxf xinput-1.6.2.tar.bz2
cd xinput-1.6.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xinput-1.6.2

