#!/bin/bash
cd /sources
tar vxf nspr-4.12.tar.gz 
cd nspr-4.12/nspr
sed -ri 's#^(RELEASE_BINS =).*#\1#' pr/src/misc/Makefile.in
sed -i 's#$(LIBRARY) ##' config/rules.mk
CC="gcc ${BUILD64}" PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" USE_ARCH=64 ./configure --prefix=/usr --libdir=/usr/lib64 --infodir=/usr/share/info --mandir=/usr/share/man --disable-debug --disable-ipv6 --enable-64bit --with-mozilla
make
make install
chmod 644 /usr/lib64/lib{nspr4,plc4,plds4}.a
rm -fv /usr/bin/{compile-et.pl,prerr.properties}
mv -v /usr/bin/nspr-config{,-64}
ln -sfv multiarch_wrapper /usr/bin/nspr-config
cat > /usr/lib64/pkgconfig/nspr.pc << "EOF"
prefix=/usr
exec_prefix=/usr/bin
libdir=/usr/lib64
includedir=/usr/include/nspr

Name: NSPR
Description: The Netscape Portable Runtime
Version: %NSPR_VERSION%
Libs: %FULL_NSPR_LIBS%
Cflags: %FULL_NSPR_CFLAGS%
EOF
sed -i -e "s@%NSPR_VERSION%@$(./config/nspr-config --version)@" -e "s@%FULL_NSPR_LIBS%@$(./config/nspr-config --libs)@" -e "s@%FULL_NSPR_CFLAGS%@$(./config/nspr-config --cflags)@" /usr/lib64/pkgconfig/nspr.pc
chmod 644 /usr/lib64/pkgconfig/nspr.pc
ln -sf nspr.pc /usr/lib64/pkgconfig/mozilla-nspr.pc
ldconfig
cd ../..
rm -vfr nspr-4.12

