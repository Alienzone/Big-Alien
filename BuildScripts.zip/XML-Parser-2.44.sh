#!/bin/bash
cd /sources
tar vxf XML-Parser-2.44.tar.gz
cd XML-Parser-2.44
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-Parser-2.44
