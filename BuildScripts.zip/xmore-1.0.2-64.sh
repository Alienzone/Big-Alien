#!/bin/bash
tar vxf xmore-1.0.2.tar.bz2
cd xmore-1.0.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xmore-1.0.2

