#!/tools/bin/bash
tar vxf ncurses-5.9.tar.gz
cd ncurses-5.9
patch -Np1 -i ../ncurses-5.9-branch_update-4.patch
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --libdir=/lib --with-shared --without-debug --enable-widec --with-manpage-format=normal --enable-pc-files --with-default-terminfo-dir=/usr/share/terminfo
make
make install
mv -v /usr/bin/ncursesw5-config{,-32}
mv -v /lib/lib{panelw,menuw,formw,ncursesw,ncurses++w}.a /usr/lib
ln -svf ../../lib/$(readlink /lib/libncursesw.so) /usr/lib/libncursesw.so
ln -svf ../../lib/$(readlink /lib/libmenuw.so) /usr/lib/libmenuw.so
ln -svf ../../lib/$(readlink /lib/libpanelw.so) /usr/lib/libpanelw.so
ln -svf ../../lib/$(readlink /lib/libformw.so) /usr/lib/libformw.so
rm -v /lib/lib{ncursesw,menuw,panelw,formw}.so
for lib in curses ncurses form panel menu ; do
        echo "INPUT(-l${lib}w)" > /usr/lib/lib${lib}.so
        ln -sfv lib${lib}w.a /usr/lib/lib${lib}.a
done
ln -sfv libcurses.so /usr/lib/libcursesw.so
ln -sfv libncurses.so /usr/lib/libcurses.so
ln -sfv libncursesw.a /usr/lib/libcursesw.a
ln -sfv libncurses.a /usr/lib/libcurses.a
ln -sfv libncurses++w.a /usr/lib/libncurses++.a
ln -sfv ncursesw5-config-32 /usr/bin/ncurses5-config-32
mkdir -v /nct
mv -v /usr/lib/pkgconfig/formw.pc /nct
mv -v /usr/lib/pkgconfig/menuw.pc /nct
mv -v /usr/lib/pkgconfig/ncurses++w.pc /nct
mv -v /usr/lib/pkgconfig/ncursesw.pc /nct
mv -v /usr/lib/pkgconfig/panelw.pc /nct
cd ..
rm -vfr ncurses-5.9

