#!/bin/bash
tar vxf mesa-12.0.1.tar.xz
cd mesa-12.0.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-texture-float --enable-gallium-osmesa --disable-gallium-llvm --with-gallium-drivers="i915,nouveau,r600,svga,swrast" --with-egl-platforms="x11,drm"
make
make install
ldconfig
cd ..
rm -vfr mesa-12.0.1

