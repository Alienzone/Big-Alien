#!/bin/bash
tar vxf xz-5.0.5.tar.xz
cd xz-5.0.5
CC="gcc ${BUILD32}" ./configure --prefix=/usr --docdir=/usr/share/doc/xz-5.0.5
make
make install
mv -v /usr/lib/liblzma.so.* /lib
ln -sfv ../../lib/$(readlink /usr/lib/liblzma.so) /usr/lib/liblzma.so
cd ..
rm -vfr xz-5.0.5

