#!/bin/bash
tar vxf binutils-2.24.tar.bz2
cd binutils-2.24
mkdir -v ../binutils-build
cd ../binutils-build
../binutils-2.24/configure --prefix=/tools --libdir=/tools/lib64 --with-lib-path=/tools/lib64:/tools/lib --build=${__A_HOST} --host=${__A_TARGET} --target=${__A_TARGET} --disable-nls --enable-shared --enable-64-bit-bfd
make
make install
cd ..
rm -vfr binutils-build
rm -vfr binutils-2.24

