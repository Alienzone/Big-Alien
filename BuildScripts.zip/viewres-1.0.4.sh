#!/bin/bash
cd /sources
tar vxf videoproto-2.3.3.tar.bz2
cd videoproto-2.3.3
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make install
ldconfig
cd ..
rm -vfr videoproto-2.3.3

