#!/bin/bash
cd /sources
tar vxf pango-1.37.5.tar.xz
cd pango-1.37.5
sed -i "/seems to be moved/s/^/#/" ltmain.sh
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" USE_ARCH=64 ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-introspection=no
make
make install
ldconfig
cd ..
rm -vfr pango-1.37.5

