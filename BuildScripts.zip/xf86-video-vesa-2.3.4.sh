#!/bin/bash
cd /sources
tar vxf xf86-video-vesa-2.3.4.tar.bz2
cd xf86-video-vesa-2.3.4
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xf86-video-vesa-2.3.4

