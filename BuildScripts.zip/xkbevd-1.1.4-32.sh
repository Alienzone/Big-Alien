#!/bin/bash
tar vxf xkbevd-1.1.4.tar.bz2
cd xkbevd-1.1.4
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xkbevd-1.1.4

