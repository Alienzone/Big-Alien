#!/bin/bash
cd /sources
tar vxf upower-0.99.4.tar.xz
cd upower-0.99.4
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --localstatedir=/var --disable-static --enable-deprecated --disable-gtk-doc-html --disable-man-pages
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" make
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" make install
ldconfig
cd ..
rm -vfr upower-0.99.4

