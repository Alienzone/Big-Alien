#!/bin/bash
cd /sources
tar vxf pcre-8.39.tar.bz2
cd pcre-8.39
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --enable-pcre16 --enable-pcre32 --enable-utf --enable-unicode-properties --enable-pcretest-libreadline
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr pcre-8.39

