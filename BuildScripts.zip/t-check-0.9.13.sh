#!/bin/bash
tar vxf check-0.9.13.tar.gz
cd check-0.9.13
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}  --libdir=/tools/lib64
make
make install
cd ..
rm -vfr check-0.9.13

