#!/bin/bash
tar vxf xz-5.0.5.tar.xz
cd xz-5.0.5
CC="gcc ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --docdir=/usr/share/doc/xz-5.0.5
make
make install
mv -v /usr/bin/{xz,lzma,lzcat,unlzma,unxz,xzcat} /bin
mv -v /usr/lib64/liblzma.so.* /lib64
ln -sfv ../../lib64/$(readlink /usr/lib64/liblzma.so) /usr/lib64/liblzma.so
cd ..
rm -vfr xz-5.0.5

