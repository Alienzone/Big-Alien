#!/bin/bash
tar vxf xorg-server-1.18.4.tar.bz2
cd xorg-server-1.18.4
patch -Np1 -i ../xorg-server-1.18.4-add_prime_support-1.patch
USE_ARCH=32 PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc --enable-glamor --enable-install-setuid --enable-suid-wrapper --disable-systemd-logind --with-xkb-output=/var/lib/xkb --with-os-name=Alien --with-builderstring="Made in Space" --host="${__A_TARGET32}"
make
make install
ldconfig
cd ..
rm -vfr xorg-server-1.18.4

