#!/tools/bin/bash
tar vxf zlib-1.2.8.tar.xz
cd zlib-1.2.8
CC="gcc -isystem /usr/include ${BUILD64}" CXX="g++ -isystem /usr/include ${BUILD64}" LDFLAGS="-Wl,-rpath-link,/usr/lib64:/lib64 ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64
make
make install
mv -v /usr/lib64/libz.so.* /lib64
ln -sfv ../../lib64/$(readlink /usr/lib64/libz.so) /usr/lib64/libz.so
cd ..
rm -vfr zlib-1.2.8

