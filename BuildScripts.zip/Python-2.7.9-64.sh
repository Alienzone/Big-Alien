#!/bin/bash
cd /sources
source /etc/profile
mkdir -vp ~/.local/lib/python2.7/site-packages
tar vxf Python-2.7.9.tar.xz
cd Python-2.7.9
patch -Np1 -i ../Python-multilib.patch
sed -i -e "s|@@MULTILIB_DIR@@|/lib64|g" Lib/distutils/command/install.py Lib/distutils/sysconfig.py Lib/pydoc.py Lib/site.py Lib/sysconfig.py Lib/test/test_dl.py Lib/test/test_site.py Lib/trace.py Makefile.pre.in Modules/getpath.c setup.py
sed -i 's@lib/python@lib64/python@g' Modules/getpath.c
export USE_ARCH=64
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" LDFLAGS="-L/usr/lib64" ./configure --prefix=/usr --libdir=/usr/lib64 --enable-shared --enable-big-digits --enable-unicode --with-pth --with-system-expat --with-system-ffi --disable-ipv6
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" make
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" make install
mv -v /usr/bin/python{,-64}
mv -v /usr/bin/python2{,-64}
mv -v /usr/bin/python2.7{,-64}
ln -sfv python2.7-64 /usr/bin/python2-64
ln -sfv python2-64 /usr/bin/python-64
ln -sfv multiarch_wrapper /usr/bin/python
ln -sfv multiarch_wrapper /usr/bin/python2
ln -sfv multiarch_wrapper /usr/bin/python2.7
mv -v /usr/include/python2.7/pyconfig{,-64}.h
cat > /usr/include/python2.7/pyconfig.h << "EOF"
/* pyconfig.h - Stub Header  */
#ifndef __STUB__PYCONFIG_H__
#define __STUB__PYCONFIG_H__

#if defined(__x86_64__) || \
    defined(__sparc64__) || \
    defined(__arch64__) || \
    defined(__powerpc64__) || \
    defined (__s390x__)
# include "pyconfig-64.h"
#else
# include "pyconfig-32.h"
#endif

#endif /* __STUB__PYCONFIG_H__ */
EOF
unset USE_ARCH
EOF
ldconfig
cd ..
rm -vfr Python-2.7.9

