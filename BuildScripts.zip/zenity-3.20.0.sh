#!/bin/bash
cd /sources
tar vxf zenity-3.20.0.tar.xz
cd ZENITY_3_20_0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./autogen.sh --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr ZENITY_3_20_0

