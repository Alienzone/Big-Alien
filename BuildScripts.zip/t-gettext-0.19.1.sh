#!/bin/bash
tar vxf gettext-0.19.1.tar.gz
cd gettext-0.19.1/gettext-tools
echo "gl_cv_func_wcwidth_works=yes" > config.cache
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --disable-shared --cache-file=config.cache
make -C gnulib-lib
make -C src msgfmt
cp -v src/msgfmt /tools/bin
cd ../..
rm -vfr gettext-0.19.1

