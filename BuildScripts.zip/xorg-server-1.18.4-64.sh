#!/bin/bash
tar vxf xorg-server-1.18.4.tar.bz2
cd xorg-server-1.18.4
patch -Np1 -i ../xorg-server-1.18.4-add_prime_support-1.patch
USE_ARCH=64 PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --enable-glamor --enable-install-setuid --enable-suid-wrapper --disable-systemd-logind --with-xkb-output=/var/lib/xkb --with-os-name=Alien --with-builderstring="Made in Space" --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xorg-server-1.18.4

