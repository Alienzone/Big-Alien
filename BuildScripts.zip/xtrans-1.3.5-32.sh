#!/bin/bash
tar vxf xtrans-1.3.5.tar.bz2
cd xtrans-1.3.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
mv -v /usr/share/pkgconfig/xtrans.pc /usr/lib/pkgconfig/xtrans.pc
cd ..
rm -vfr xtrans-1.3.5

