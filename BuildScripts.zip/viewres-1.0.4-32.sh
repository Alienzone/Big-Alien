#!/bin/bash
tar vxf videoproto-2.3.3.tar.bz2
cd videoproto-2.3.3
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
cd ..
rm -vfr videoproto-2.3.3

