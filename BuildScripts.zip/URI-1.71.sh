#!/bin/bash
cd /sources
tar vxf URI-1.71.tar.gz
cd URI-1.71
perl Makefile.PL
make
make install
cd ..
rm -vfr URI-1.71

