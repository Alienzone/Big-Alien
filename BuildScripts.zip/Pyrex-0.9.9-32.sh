#!/bin/bash
tar vxf Pyrex-0.9.9.tar.gz
cd Pyrex-0.9.9
USE_ARCH=32 python setup.py build --build-base=build32
USE_ARCH=32 python setup.py install --prefix=/usr --install-purelib=/usr/lib/python2.7/site-packages
cd ..
rm -vfr Pyrex-0.9.9

