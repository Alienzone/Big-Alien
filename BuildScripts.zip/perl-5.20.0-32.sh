#!/tools/bin/bash
tar vxf perl-5.20.0.tar.bz2
cd perl-5.20.0
export BUILD_ZLIB=False
export BUILD_BZIP2=0
ip link set lo up
echo "127.0.0.1 localhost Alien" > /etc/hosts
  ./configure.gnu --prefix=/usr -Dvendorprefix=/usr -Dman1dir=/usr/share/man/man1 -Dman3dir=/usr/share/man/man3 -Dpager="/bin/less -isR" -Dcc="gcc ${BUILD32}" -Dusethreads -Duseshrplib
make
make install
unset BUILD_ZLIB BUILD_BZIP2
mv -v /usr/bin/perl{,-32}
mv -v /usr/bin/perl5.20.0{,-32}
cd ..
rm -vfr perl-5.20.0

