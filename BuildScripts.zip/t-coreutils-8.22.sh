#!/bin/bash
tar vxf coreutils-8.22.tar.xz
cd coreutils-8.22
cat > config.cache << EOF
fu_cv_sys_stat_statfs2_bsize=yes
gl_cv_func_working_mkstemp=yes
EOF
patch -Np1 -i ../coreutils-8.22-noman-1.patch
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --enable-install-program=hostname --cache-file=config.cache
make
make install
cd ..
rm -vfr coreutils-8.22

