#!/bin/bash
cd /sources
tar vxf Net-HTTP-6.09.tar.gz
cd Net-HTTP-6.09
perl Makefile.PL
make
make install
cd ..
rm -vfr Net-HTTP-6.09

