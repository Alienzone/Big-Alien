#!/bin/bash
tar vxf gcc-4.8.3.tar.bz2
cd gcc-4.8.3
patch -Np1 -i ../gcc-4.8.3-branch_update-1.patch
patch -Np1 -i ../gcc-4.8.3-specs-1.patch
echo -en '\n#undef STANDARD_STARTFILE_PREFIX_1\n#define STANDARD_STARTFILE_PREFIX_1 "/tools/lib/"\n' >> gcc/config/linux.h
echo -en '\n#undef STANDARD_STARTFILE_PREFIX_2\n#define STANDARD_STARTFILE_PREFIX_2 ""\n' >> gcc/config/linux.h
cp -v gcc/Makefile.in{,.orig}
sed 's@\./fixinc\.sh@-c true@' gcc/Makefile.in.orig > gcc/Makefile.in
mkdir -v ../gcc-build
cd ../gcc-build
../gcc-4.8.3/configure --prefix=/tools --libdir=/tools/lib64 --build=${__A_HOST} --host=${__A_TARGET} --target=${__A_TARGET} --with-local-prefix=/tools --disable-nls --enable-languages=c,c++ --disable-libstdcxx-pch --with-system-zlib --with-native-system-header-dir=/tools/include --disable-libssp --enable-libstdcxx-time --enable-checking=release
cp -v Makefile{,.orig}
sed "/^HOST_\(GMP\|ISL\|CLOOG\)\(LIBS\|INC\)/s:/tools:/cross-tools:g" Makefile.orig > Makefile
make AS_FOR_TARGET="${AS}" LD_FOR_TARGET="${LD}"
make install
cp -v ../gcc-4.8.3/include/libiberty.h /tools/include
cd ..
rm -vfr gcc-build
rm -vfr gcc-4.8.3

