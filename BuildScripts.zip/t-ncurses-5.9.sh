#!/bin/bash
tar vxf ncurses-5.9.tar.gz
cd ncurses-5.9
patch -Np1 -i ../ncurses-5.9-bash_fix-1.patch
./configure --prefix=/tools --with-shared --build=${__A_HOST} --host=${__A_TARGET} --without-debug --without-ada --enable-overwrite --with-build-cc=gcc --libdir=/tools/lib64
make
make install
cd ..
rm -vfr ncurses-5.9

