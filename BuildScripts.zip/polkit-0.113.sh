#!/bin/bash
cd /sources
tar vxf polkit-0.113.tar.gz
cd polkit-0.113
groupadd -fg 28 polkitd
useradd -c "PolicyKit Daemon Owner" -d /etc/polkit-1 -u 28 -g polkitd -s /bin/false polkitd
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-libsystemd-login=no --enable-instrospection=no --disable-static --localstatedir=/var --with-authfw=shadow --disable-man-pages --disable-gtk-doc --disable-gtk-doc-html --disable-gtk-doc-pdf --disable-test
make
make install
ldconfig
cd ..
rm -vfr polkit-0.113

