#!/bin/bash
tar vxf scrnsaverproto-1.2.2.tar.bz2
cd scrnsaverproto-1.2.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make install
ldconfig
cd ..
rm -vfr scrnsaverproto-1.2.2

