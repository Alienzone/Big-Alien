#!/bin/bash
tar vxf twm-1.0.9.tar.bz2
cd twm-1.0.9
sed -i -e '/^rcdir =/s,^\(rcdir = \).*,\1/etc/X11/app-defaults,' src/Makefile.in
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr twm-1.0.9

