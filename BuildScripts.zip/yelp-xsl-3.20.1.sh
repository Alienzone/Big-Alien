#!/bin/bash
cd /sources
tar vxf yelp-xsl-3.20.1.tar.xz
cd yelp-xsl-3.20.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
mv -v /usr/share/pkgconfig/yelp-xsl.pc /usr/lib64/pkgconfig/yelp-xsl.pc
ldconfig
cd ..
rm -vfr yelp-xsl-3.20.1

