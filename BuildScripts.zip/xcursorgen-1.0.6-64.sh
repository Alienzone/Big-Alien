#!/bin/bash
tar vxf xcursorgen-1.0.6.tar.bz2
cd xcursorgen-1.0.6
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xcursorgen-1.0.6

