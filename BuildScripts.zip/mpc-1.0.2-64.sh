#!/tools/bin/bash
tar vxf mpc-1.0.2.tar.gz
cd mpc-1.0.2
CC="gcc -isystem /usr/include ${BUILD64}" LDFLAGS="-Wl,-rpath-link,/usr/lib64:/lib64 ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --docdir=/usr/share/doc/mpc-1.0.2
make
make install
cd ..
rm -vfr mpc-1.0.2

