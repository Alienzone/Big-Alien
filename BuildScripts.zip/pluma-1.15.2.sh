#!/bin/bash
cd /sources
tar vxf pluma-1.15.2.tar.xz
cd pluma-1.15.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --disable-spell
make
make install
ldconfig
cd ..
rm -vfr pluma-1.15.2

