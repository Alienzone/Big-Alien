#!/bin/bash
cd /sources
tar vxf xfwp-1.0.3.tar.bz2
cd xfwp-1.0.3
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --disable-selective-werror
make
make install
ldconfig
cd ..
rm -vfr xfwp-1.0.3

