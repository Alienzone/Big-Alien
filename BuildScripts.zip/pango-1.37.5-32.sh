#!/bin/bash
tar vxf pango-1.37.5.tar.xz
cd pango-1.37.5
sed -i "/seems to be moved/s/^/#/" ltmain.sh
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" USE_ARCH=32 ./configure --prefix=/usr --sysconfdir=/etc --enable-introspection=no
make
make install
ldconfig
cd ..
rm -vfr pango-1.37.5

