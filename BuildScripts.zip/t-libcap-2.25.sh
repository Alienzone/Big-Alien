#!/bin/bash
tar vxf libcap-2.25.tar.xz
cd libcap-2.25
#make CC="${CC}" LD="${LD}"
make
make RAISE_SETFCAP=no prefix=/tools install
cd ..
rm -vfr libcap-2.25

