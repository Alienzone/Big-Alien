#!/bin/bash
tar vxf sed-4.2.2.tar.bz2
cd sed-4.2.2
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr sed-4.2.2

