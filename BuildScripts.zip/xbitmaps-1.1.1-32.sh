#!/bin/bash
tar vxf xbitmaps-1.1.1.tar.bz2
cd xbitmaps-1.1.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
mv -v /usr/share/pkgconfig/xbitmaps.pc /usr/lib/pkgconfig/xbitmaps.pc
ldconfig
cd ..
rm -vfr xbitmaps-1.1.1

