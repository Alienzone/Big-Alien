#!/bin/bash
tar vxf unzip60.tar.gz
cd unzip60
make -f unix/Makefile generic CC="gcc ${BUILD64} -DUSE_BZIP2 -lbz2"
make -f unix/Makefile prefix=/usr install
cd ..
rm -vfr unzip60

