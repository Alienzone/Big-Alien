#!/bin/bash
tar vxf xz-5.0.5.tar.xz
cd xz-5.0.5
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET} --libdir=/tools/lib64
make
make install
cd ..
rm -vfr xz-5.0.5

