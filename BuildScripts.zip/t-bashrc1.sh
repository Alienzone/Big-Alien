#!/bin/bash
cat > /mnt/__a/home/__a/.bashrc << "EOF"
set +h
umask 022
__A=/mnt/__a
LC_ALL=POSIX
PATH=/cross-tools/bin:/bin:/usr/bin
export __A LC_ALL PATH
unset CFLAGS CXXFLAGS
export __A_HOST="x86_64-cross-linux-gnu"
export __A_TARGET="x86_64-unknown-linux-gnu"
export __A_TARGET32="i686-pc-linux-gnu"
export BUILD32="-m32"
export BUILD64="-m64"
export MAKEFLAGS="-j 4"
export CC="x86_64-unknown-linux-gnu-gcc -m64"
export CXX="x86_64-unknown-linux-gnu-g++ -m64"
export AR="x86_64-unknown-linux-gnu-ar"
export AS="x86_64-unknown-linux-gnu-as"
export RANLIB="x86_64-unknown-linux-gnu-ranlib"
export LD="x86_64-unknown-linux-gnu-ld"
export STRIP="x86_64-unknown-linux-gnu-strip"
EOF
