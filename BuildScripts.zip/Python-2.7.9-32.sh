#!/bin/bash
cd /sources
source /etc/profile
mkdir -vp ~/.local/lib/python2.7/site-packages
tar vxf Python-2.7.9.tar.xz
cd Python-2.7.9
sed -i 's@/lib64@/lib@g' Modules/_ctypes/libffi/m4/libtool.m4 Modules/_ctypes/libffi/configure setup.py
sed -i "s/'lib64'/'lib'/g" setup.py
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --enable-shared --enable-big-digits --enable-unicode --with-pth --with-system-expat --with-system-ffi --disable-ipv6
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" make
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" make install
mv -v /usr/bin/python{,-32}
mv -v /usr/bin/python2{,-32}
mv -v /usr/bin/python2.7{,-32}
mv -v /usr/include/python2.7/pyconfig{,-32}.h
ln -sfv python2.7-32 /usr/bin/python2-32
ln -sfv python2-32 /usr/bin/python-32
cd ..
rm -vfr Python-2.7.9

