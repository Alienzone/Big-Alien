#!/bin/bash
tar vxf patch-2.7.1.tar.xz
cd patch-2.7.1
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr patch-2.7.1

