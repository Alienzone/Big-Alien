#!/bin/bash
cd /sources
tar vxf py2cairo-1.10.0.tar.bz2
cd py2cairo-1.10.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" ./waf configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib
./waf build
./waf install
ldconfig
cd ..
rm -vfr py2cairo-1.10.0

tar vxf py2cairo-1.10.0.tar.bz2
cd py2cairo-1.10.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" ./waf configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
./waf build
./waf install
ldconfig
cd ..
rm -vfr py2cairo-1.10.0

