#!/bin/bash
tar vxf xkeyboard-config-2.18.tar.bz2
cd xkeyboard-config-2.18
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --with-xkb-rules-symlink=xorg
make
make install
ldconfig
mv -v /usr/share/pkgconfig/* /usr/lib64/pkgconfig/
cd ..
rm -vfr xkeyboard-config-2.18

