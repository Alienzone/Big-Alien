#!/bin/bash
tar vxf file-5.19.tar.gz
cd file-5.19
./configure --prefix=/tools --libdir=/tools/lib64 --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr file-5.19

