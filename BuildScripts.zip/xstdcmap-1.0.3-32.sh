#!/bin/bash
tar vxf xstdcmap-1.0.3.tar.bz2
cd xstdcmap-1.0.3
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xstdcmap-1.0.3

