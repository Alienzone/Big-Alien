#!/bin/bash
tar vxf mesa-12.0.1.tar.xz
cd mesa-12.0.1
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc --host="${__A_TARGET32}" --enable-texture-float --enable-gallium-osmesa --disable-gallium-llvm --with-gallium-drivers="i915,nouveau,r600,svga,swrast" --with-egl-platforms="x11,drm"
make
make install
ldconfig
cd ..
rm -vfr mesa-12.0.1

