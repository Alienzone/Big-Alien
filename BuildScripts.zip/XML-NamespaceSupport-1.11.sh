#!/bin/bash
cd /sources
tar vxf XML-NamespaceSupport-1.11.tar.gz
cd XML-NamespaceSupport-1.11
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-NamespaceSupport-1.11

