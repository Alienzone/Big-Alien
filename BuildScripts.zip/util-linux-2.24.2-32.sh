#!/tools/bin/bash
tar vxf util-linux-2.24.2.tar.xz
cd util-linux-2.24.2
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" ./configure --libdir=/lib --enable-write --docdir=/usr/share/doc/util-linux-2.24.2
make
make install
cd ..
rm -vfr util-linux-2.24.2

