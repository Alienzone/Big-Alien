#!/bin/bash
cd /sources
tar vxf nspr-4.12.tar.gz 
cd nspr-4.12/nspr
sed -ri 's#^(RELEASE_BINS =).*#\1#' pr/src/misc/Makefile.in
sed -i 's#$(LIBRARY) ##' config/rules.mk
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-64bit --enable-x32 --with-mozilla --with-pthreads
make
make install
ldconfig
cd ../..
rm -vfr nspr-4.12

