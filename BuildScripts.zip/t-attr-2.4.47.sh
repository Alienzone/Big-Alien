#!/bin/bash
tar vxf attr-2.4.47.src.tar.gz
cd attr-2.4.47
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}  --libdir=/tools/lib64
make
make install install-dev install-lib
cd ..
rm -vfr attr-2.4.47

