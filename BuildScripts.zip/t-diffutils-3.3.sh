#!/bin/bash
tar vxf diffutils-3.3.tar.xz
cd diffutils-3.3
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}
make
make install
cd ..
rm -vfr diffutils-3.3

