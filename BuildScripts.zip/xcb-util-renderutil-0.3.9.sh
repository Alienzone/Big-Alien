#!/bin/bash
cd /sources
tar vxf xcb-util-renderutil-0.3.9.tar.bz2
cd xcb-util-renderutil-0.3.9
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr xcb-util-renderutil-0.3.9

