#!/bin/bash
tar vxf XML-SAX-Base-1.08.tar.gz
cd XML-SAX-Base-1.08
perl Makefile.PL
make
make install
cd ..
rm -vfr XML-SAX-Base-1.08

