#!/tools/bin/bash
tar vxf perl-5.20.0.tar.bz2
cd perl-5.20.0
sed -i -e '/^BUILD_ZLIB/s/True/False/' -e '/^INCLUDE/s,\./zlib-src,/usr/include,' -e '/^LIB/s,\./zlib-src,/usr/lib64,' cpan/Compress-Raw-Zlib/config.in
patch -Np1 -i ../perl-5.20.0-Configure_multilib-1.patch
echo 'installstyle="lib64/perl5"' >> hints/linux.sh
./configure.gnu --prefix=/usr -Dvendorprefix=/usr -Dman1dir=/usr/share/man/man1 -Dman3dir=/usr/share/man/man3 -Dpager="/bin/less -isR" -Dlibpth="/usr/local/lib64 /lib64 /usr/lib64" -Dcc="gcc ${BUILD64}" -Dusethreads -Duseshrplib
make
make install
unset BUILD_ZLIB BUILD_BZIP2
mv -v /usr/bin/perl{,-64}
mv -v /usr/bin/perl5.20.0{,-64}
ln -sv multiarch_wrapper /usr/bin/perl
ln -sv multiarch_wrapper /usr/bin/perl5.20.0
cd ..
rm -vfr perl-5.20.0

