#!/bin/bash
cd /sources
tar vxf xf86-input-evdev-2.10.3.tar.bz2
cd xf86-input-evdev-2.10.3
CXX="g++ ${BUILD64}" CC="gcc ${BUILD64}" PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr xf86-input-evdev-2.10.3

