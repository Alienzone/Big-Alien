#!/bin/bash
tar vxf xinit-1.3.4.tar.bz2
cd xinit-1.3.4
sed -e '/$serverargs $vtarg/ s/serverargs/: #&/' -i startx.cpp
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc --with-xinitdir=/etc/X11/app-defaults
make
make install
ldconfig
cd ..
rm -vfr xinit-1.3.4

