#!/bin/bash
cd /sources
tar vxf pcre-8.39.tar.bz2
cd pcre-8.39
CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --libdir=/usr/lib --enable-pcre16 --enable-pcre32 --enable-utf --enable-unicode-properties --enable-pcretest-libreadline --enable-pcregrep-libz  --enable-pcregrep-libbz2 --enable-pcretest-libreadline
make
make install
mv -v /usr/bin/pcre-config{,-32}
mv -v /usr/lib/libpcre.so.* /lib/
ln -svf ../../lib/libpcre.so.1 /usr/lib/libpcre.so
ldconfig
cd ..
rm -vfr pcre-8.39

