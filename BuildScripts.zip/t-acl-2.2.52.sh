#!/bin/bash
tar vxf acl-2.2.52.src.tar.gz
cd acl-2.2.52
./configure --prefix=/tools --build=${__A_HOST} --host=${__A_TARGET}  --libdir=/tools/lib64
make
make install install-dev install-lib
cd ..
rm -vfr acl-2.2.52

