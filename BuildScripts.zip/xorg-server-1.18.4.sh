#!/bin/bash
cd /sources
tar vxf xorg-server-1.18.4.tar.bz2
cd xorg-server-1.18.4
patch -Np1 -i ../xorg-server-1.18.4-add_prime_support-1.patch
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --enable-glamor --enable-install-setuid --enable-suid-wrapper --disable-systemd-logind --with-xkb-output=/var/lib/xkb
make
make install
mkdir -pv /etc/X11/xorg.conf.d
cat >> /etc/sysconfig/createfiles << "EOF"
/tmp/.ICE-unix dir 1777 root root
/tmp/.X11-unix dir 1777 root root
EOF
ldconfig
cd ..
rm -vfr xorg-server-1.18.4

