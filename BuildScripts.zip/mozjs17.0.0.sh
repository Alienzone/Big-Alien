#!/bin/bash
cd /sources
tar vxf mozjs17.0.0.tar.gz
cd mozjs17.0.0/js/src
sed -i 's/(defined\((@TEMPLATE_FILE)\))/\1/' config/milestone.pl
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --with-x --disable-tests --enable-readline --enable-threadsafe --with-system-ffi --with-system-nspr
make
make install
find /usr/include/js-17.0/ /usr/lib/libmozjs-17.0.a /usr/lib/pkgconfig/mozjs-17.0.pc -type f -exec chmod -v 644 {} \;
ldconfig
cd ../../..
rm -vfr mozjs17.0.0

