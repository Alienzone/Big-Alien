#!/tools/bin/bash
tar vxf tcl8.6.1-src.tar.gz
cd tcl8.6.1
sed -i s/500/5000/ generic/regc_nfa.c
cd unix
CC="gcc ${BUILD64}" ./configure --prefix=/tools --libdir=/tools/lib64
make
make install
make install-private-headers
ln -sv tclsh8.6 /tools/bin/tclsh
cd ../..
rm -vfr tcl8.6.1

