#!/bin/bash
tar vxf sharutils-4.15.2.tar.xz
cd sharutils-4.15.2
CC="gcc ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64
make
make install
ldconfig
cd ..
rm -vfr sharutils-4.15.2

