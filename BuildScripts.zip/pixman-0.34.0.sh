#!/bin/bash
cd /sources
tar vxf pixman-0.34.0.tar.bz2
cd pixman-0.34.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr pixman-0.34.0

