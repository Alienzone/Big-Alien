#!/bin/bash
tar vxf tiff-4.0.6.tar.gz
cd tiff-4.0.6
sed -i "/seems to be moved/s/^/#/" config/ltmain.sh
CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" USE_ARCH=64 LDFLAGS="-L/usr/lib64" ./configure --prefix=/usr --libdir=/usr/lib64 --disable-static
make
make install
mv -v /usr/include/tiffconf{,-64}.h
cat > /usr/include/tiffconf.h << "EOF"
/* tiffconf.h - Stub Header  */
#ifndef __STUB__TIFFCONF_H__
#define __STUB__TIFFCONF_H__

#if defined(__x86_64__) || \
    defined(__sparc64__) || \
    defined(__arch64__) || \
    defined(__powerpc64__) || \
    defined (__s390x__)
# include "tiffconf-64.h"
#else
# include "tiffconf-32.h"
#endif

#endif /* __STUB__TIFFCONF_H__ */
EOF
ldconfig
cd ..
rm -vfr tiff-4.0.6

