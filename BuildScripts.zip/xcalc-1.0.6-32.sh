#!/bin/bash
tar vxf xcalc-1.0.6.tar.bz2
cd xcalc-1.0.6
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xcalc-1.0.6

