#!/bin/bash
cd /sources
tar vxf poppler-0.47.0.tar.xz
cd poppler-0.47.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib64 --disable-static --enable-build-type=release --enable-cmyk --enable-xpdf-headers --disable-poppler-qt4 --disable-poppler-qt5
make
make install
tar -xf ../poppler-data-0.4.7.tar.gz
cd poppler-data-0.4.7
make prefix=/usr install
mv -v /usr/share/pkgconfig/poppler-data.pc /usr/lib64/pkgconfig/poppler-data.pc
ldconfig
cd ../..
rm -vfr poppler-0.47.0

