#!/bin/bash
tar vxf presentproto-1.0.tar.bz2
cd presentproto-1.0
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make install
ldconfig
cd ..
rm -vfr presentproto-1.0

