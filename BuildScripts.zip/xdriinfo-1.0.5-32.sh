#!/bin/bash
tar vxf xdriinfo-1.0.5.tar.bz2
cd xdriinfo-1.0.5
PKG_CONFIG_PATH="${PKG_CONFIG_PATH32}" CC="gcc ${BUILD32}" CXX="g++ ${BUILD32}" ./configure --prefix=/usr --sysconfdir=/etc
make
make install
ldconfig
cd ..
rm -vfr xdriinfo-1.0.5

