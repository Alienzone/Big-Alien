#!/bin/bash
cd /sources
tar vxf tiff-4.0.6.tar.gz
cd tiff-4.0.6
sed -i "/seems to be moved/s/^/#/" config/ltmain.sh
PKG_CONFIG_PATH="${PKG_CONFIG_PATH64}" CC="gcc ${BUILD64}" CXX="g++ ${BUILD64}" ./configure --prefix=/usr --libdir=/usr/lib64 --disable-static
sleep 3
make
sleep 3
make install
sleep 3
ldconfig
cd ..
rm -vfr tiff-4.0.6

